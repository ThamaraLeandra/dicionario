#ifndef PALAVRAS_INICIAIS_H
#define PALAVRAS_INICIAIS_H

#include "dicionario.h"

void carregarPalavrasIniciais(Palavra **dicionario);

#endif
