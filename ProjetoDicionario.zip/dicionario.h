#ifndef DICIONARIO_H
#define DICIONARIO_H

typedef struct Palavra {
    char portugues[50];
    char ingles[50];
    struct Palavra *prox;
} Palavra;

void toLower(char *str);
void inserirPalavra(Palavra **inicio, char *pt, char *en);
void removerPalavra(Palavra **inicio, char *pt);
char* buscarTraducao(Palavra *inicio, char *palavra, int paraIngles);
void exibirDicionario(Palavra *inicio);
void traduzirTexto(Palavra *inicio, char *texto, int paraIngles);

#endif
